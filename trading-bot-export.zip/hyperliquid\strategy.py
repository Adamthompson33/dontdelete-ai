"""
Hyperliquid Trading Strategy - 2026 Downside Specialist
========================================================

Two separate modes for two market conditions:

1. TRENDING MODE (13/33 cross confirmed)
   → Simple leveraged position
   → Ride the big move with a stop loss
   → No grid, no complexity

2. CHOPPY MODE (no clear trend)
   → Neutral grid bot
   → Buy dips, sell rips
   → Small consistent profits from volatility

Author: Si + Jackbot
Thesis: Fire Horse year (2026) clashes with BTC's Rat year (2008)
Target: BTC to $40k or lower
"""

import pandas as pd
from hyperliquid.info import Info
from hyperliquid.exchange import Exchange
from hyperliquid.utils import constants
import os
from datetime import datetime

# === CONFIGURATION ===
AGENT_KEY = os.getenv("HL_AGENT_KEY")
ACCOUNT_ADDR = os.getenv("HL_MAIN_ADDR")
SYMBOL = "BTC"

# Leverage settings - bearish 2026 bias
LEVERAGE_SHORT = 10  # More aggressive on downside (was 7)
LEVERAGE_LONG = 3    # Conservative on upside

# Grid settings for choppy mode
GRID_LEVELS = 5
GRID_SPACING_PCT = 0.01  # 1% between levels
GRID_SIZE_USD = 100      # USD per grid order

# Stop loss settings
STOP_LOSS_PCT = 0.04     # 4% stop loss on trend trades

# Flash crash settings (wick catching)
CRASH_LEVELS = [0.10, 0.15, 0.20, 0.25, 0.30]  # 10%, 15%, 20%, 25%, 30% below
CRASH_SIZE_USD = 200     # USD per crash order (larger because rare opportunity)
CRASH_TAKE_PROFIT_PCT = 0.05  # Take profit at 5% bounce from fill

# Initialize clients (comment out for paper trading)
# info = Info(constants.MAINNET_API_URL, skip_ws=True)
# exchange = Exchange(ACCOUNT_ADDR, AGENT_KEY, constants.MAINNET_API_URL)

# For testing - use None
info = None
exchange = None


def get_candles(coin: str, timeframe: str = "1d", limit: int = 50) -> pd.DataFrame:
    """Fetch candle data and return as DataFrame."""
    if info is None:
        # Return dummy data for testing
        print("⚠️ Running in test mode - no live data")
        return None
    
    candles = info.candle_snapshot(coin, timeframe, startTime=0, endTime=0)
    df = pd.DataFrame(candles)
    df['close'] = df['c'].astype(float)
    df['high'] = df['h'].astype(float)
    df['low'] = df['l'].astype(float)
    df['open'] = df['o'].astype(float)
    return df.tail(limit)


def detect_market_regime(coin: str) -> dict:
    """
    Determine if market is TRENDING or CHOPPY using 13/33 MA cross.
    
    Returns:
        dict with:
        - regime: "TRENDING_SHORT" | "TRENDING_LONG" | "CHOPPY"
        - ma13: current 13 MA value
        - ma33: current 33 MA value
        - ma_diff_pct: percentage difference between MAs
        - fresh_cross: True if cross happened in last 3 days
    """
    df = get_candles(coin)
    
    if df is None:
        # Test mode - return sample data
        return {
            'regime': 'TRENDING_SHORT',
            'ma13': 75000,
            'ma33': 78000,
            'ma_diff_pct': -3.85,
            'fresh_cross': False,
            'price': 74000
        }
    
    # Calculate MAs
    df['ma13'] = df['close'].rolling(window=13).mean()
    df['ma33'] = df['close'].rolling(window=33).mean()
    
    current = df.iloc[-1]
    ma13 = current['ma13']
    ma33 = current['ma33']
    price = current['close']
    
    # Calculate MA difference as percentage
    ma_diff_pct = ((ma13 - ma33) / ma33) * 100
    
    # Check for fresh cross (within last 3 days)
    fresh_cross = False
    for i in range(-3, 0):
        prev = df.iloc[i-1]
        curr = df.iloc[i]
        if (prev['ma13'] >= prev['ma33'] and curr['ma13'] < curr['ma33']) or \
           (prev['ma13'] <= prev['ma33'] and curr['ma13'] > curr['ma33']):
            fresh_cross = True
            break
    
    # Determine regime
    # If MAs are very close (within 1%), consider it choppy
    if abs(ma_diff_pct) < 1.0:
        regime = "CHOPPY"
    elif ma13 < ma33:
        regime = "TRENDING_SHORT"
    else:
        regime = "TRENDING_LONG"
    
    return {
        'regime': regime,
        'ma13': ma13,
        'ma33': ma33,
        'ma_diff_pct': ma_diff_pct,
        'fresh_cross': fresh_cross,
        'price': price
    }


# =============================================================================
# MODE 1: TRENDING - Simple Leveraged Position
# =============================================================================

def enter_trend_position(coin: str, direction: str, size_usd: float = 1000):
    """
    Enter a simple leveraged position in the trend direction.
    No grid, no complexity - just ride the move.
    
    Args:
        coin: Trading pair
        direction: "SHORT" or "LONG"
        size_usd: Position size in USD
    """
    regime = detect_market_regime(coin)
    price = regime['price']
    
    is_short = direction == "SHORT"
    leverage = LEVERAGE_SHORT if is_short else LEVERAGE_LONG
    
    # Calculate stop loss price
    if is_short:
        stop_price = price * (1 + STOP_LOSS_PCT)
    else:
        stop_price = price * (1 - STOP_LOSS_PCT)
    
    print(f"\n{'='*50}")
    print(f"📈 ENTERING {direction} POSITION")
    print(f"{'='*50}")
    print(f"   Coin: {coin}")
    print(f"   Price: ${price:,.2f}")
    print(f"   Direction: {direction}")
    print(f"   Leverage: {leverage}x")
    print(f"   Size: ${size_usd:,.2f}")
    print(f"   Stop Loss: ${stop_price:,.2f} ({STOP_LOSS_PCT*100:.1f}%)")
    print(f"   Liquidation: ~${price * (1 + 1/leverage) if is_short else price * (1 - 1/leverage):,.2f}")
    
    if exchange:
        # Set leverage
        exchange.update_leverage(leverage, coin, is_buy=not is_short)
        
        # Calculate size in coin units
        size = size_usd / price
        
        # Enter market order
        # exchange.market_open(coin, is_buy=not is_short, sz=size)
        
        # Set stop loss
        # exchange.order(coin, is_buy=is_short, sz=size, px=stop_price, 
        #                order_type={"trigger": {"triggerPx": stop_price, "isMarket": True, "tpsl": "sl"}})
        
        print(f"\n✅ Position opened with stop loss")
    else:
        print(f"\n⚠️ Test mode - no order placed")
    
    return {
        'action': 'ENTER_TREND',
        'direction': direction,
        'price': price,
        'leverage': leverage,
        'stop_price': stop_price
    }


def exit_trend_position(coin: str):
    """Close all positions for a coin."""
    print(f"\n🚪 Closing all {coin} positions...")
    
    if exchange:
        exchange.market_close(coin)
        print("✅ Positions closed")
    else:
        print("⚠️ Test mode - no action taken")


# =============================================================================
# MODE 2: CHOPPY - Neutral Grid Bot
# =============================================================================

def setup_neutral_grid(coin: str, center_price: float = None, size_per_level: float = None):
    """
    Set up a neutral grid that profits from chop.
    
    Places buy orders below current price and sell orders above.
    As price bounces around, it buys low and sells high repeatedly.
    
    NO directional bias - equal buys and sells.
    """
    regime = detect_market_regime(coin)
    price = center_price or regime['price']
    size = size_per_level or GRID_SIZE_USD
    
    print(f"\n{'='*50}")
    print(f"🔲 SETTING UP NEUTRAL GRID")
    print(f"{'='*50}")
    print(f"   Coin: {coin}")
    print(f"   Center Price: ${price:,.2f}")
    print(f"   Levels: {GRID_LEVELS} above + {GRID_LEVELS} below")
    print(f"   Spacing: {GRID_SPACING_PCT*100:.1f}%")
    print(f"   Size per level: ${size:.2f}")
    print(f"   Total capital needed: ${size * GRID_LEVELS * 2:,.2f}")
    
    buy_orders = []
    sell_orders = []
    
    # Place buy orders below current price
    print(f"\n   📉 BUY ORDERS (below price):")
    for i in range(1, GRID_LEVELS + 1):
        buy_price = price * (1 - GRID_SPACING_PCT * i)
        buy_orders.append({
            'side': 'BUY',
            'price': buy_price,
            'size_usd': size,
            'level': i
        })
        print(f"      Level {i}: ${buy_price:,.2f}")
        
        if exchange:
            sz = size / buy_price
            # exchange.order(coin, is_buy=True, sz=sz, px=buy_price, 
            #                order_type={"limit": {"tif": "Gtc"}})
    
    # Place sell orders above current price
    print(f"\n   📈 SELL ORDERS (above price):")
    for i in range(1, GRID_LEVELS + 1):
        sell_price = price * (1 + GRID_SPACING_PCT * i)
        sell_orders.append({
            'side': 'SELL',
            'price': sell_price,
            'size_usd': size,
            'level': i
        })
        print(f"      Level {i}: ${sell_price:,.2f}")
        
        if exchange:
            sz = size / sell_price
            # exchange.order(coin, is_buy=False, sz=sz, px=sell_price,
            #                order_type={"limit": {"tif": "Gtc"}})
    
    print(f"\n   💰 PROFIT PER ROUND TRIP:")
    profit_per_trip = size * GRID_SPACING_PCT * 2  # Buy low, sell high
    print(f"      ~${profit_per_trip:.2f} per level (before fees)")
    
    if not exchange:
        print(f"\n⚠️ Test mode - no orders placed")
    
    return {
        'action': 'SETUP_GRID',
        'center_price': price,
        'buy_orders': buy_orders,
        'sell_orders': sell_orders
    }


def cancel_grid(coin: str):
    """Cancel all grid orders."""
    print(f"\n🛑 Cancelling all {coin} grid orders...")
    
    if exchange and info:
        open_orders = info.open_orders(ACCOUNT_ADDR)
        cancelled = 0
        for order in open_orders:
            if order['coin'] == coin:
                exchange.cancel(coin, order['oid'])
                cancelled += 1
        print(f"✅ Cancelled {cancelled} orders")
    else:
        print("⚠️ Test mode - no action taken")


# =============================================================================
# MODE 3: FLASH CRASH CATCHER (Always Running)
# =============================================================================

def setup_crash_catcher(coin: str, current_price: float = None):
    """
    Flash Crash Catcher - "Wick Fishing"
    
    Places limit buy orders at extreme prices (10-30% below current).
    When a flash crash happens (like Oct 10, 2025 - $19B liquidation event),
    these orders catch the wick and profit from the bounce.
    
    This runs ALONGSIDE the main strategy. Always on.
    
    Oct 10, 2025 reference:
    - $3.21B liquidated in 60 seconds
    - BTC dropped ~15% in minutes
    - Bounced back within hours
    - Anyone with limit orders at -15% made massive profits
    """
    regime = detect_market_regime(coin)
    price = current_price or regime['price']
    
    print(f"\n{'='*50}")
    print(f"⚡ FLASH CRASH CATCHER SETUP")
    print(f"{'='*50}")
    print(f"   Purpose: Catch liquidation cascades like Oct 10, 2025")
    print(f"   Current Price: ${price:,.2f}")
    print(f"   Orders will sit and wait for extreme wicks")
    
    crash_orders = []
    total_capital = 0
    
    print(f"\n   🎯 CRASH BUY ORDERS:")
    for pct in CRASH_LEVELS:
        crash_price = price * (1 - pct)
        take_profit = crash_price * (1 + CRASH_TAKE_PROFIT_PCT)
        
        crash_orders.append({
            'type': 'CRASH_BUY',
            'trigger_drop': f"{pct*100:.0f}%",
            'buy_price': crash_price,
            'take_profit': take_profit,
            'size_usd': CRASH_SIZE_USD,
            'potential_profit': CRASH_SIZE_USD * CRASH_TAKE_PROFIT_PCT
        })
        total_capital += CRASH_SIZE_USD
        
        print(f"      {pct*100:.0f}% crash → Buy at ${crash_price:,.2f}")
        print(f"                   → TP at ${take_profit:,.2f} (+5%)")
        print(f"                   → Potential: ${CRASH_SIZE_USD * CRASH_TAKE_PROFIT_PCT:.2f}")
        print()
        
        if exchange:
            sz = CRASH_SIZE_USD / crash_price
            # Place limit buy order
            # exchange.order(coin, is_buy=True, sz=sz, px=crash_price,
            #                order_type={"limit": {"tif": "Gtc"}})
            
            # Place take-profit order (linked)
            # This would need to be done after the buy fills
    
    print(f"   💰 TOTAL CAPITAL RESERVED: ${total_capital:,.2f}")
    print(f"   📊 IF ALL HIT: ${total_capital * CRASH_TAKE_PROFIT_PCT:,.2f} profit")
    print(f"\n   ⏳ These orders wait quietly until chaos strikes...")
    
    if not exchange:
        print(f"\n⚠️ Test mode - no orders placed")
    
    return {
        'action': 'SETUP_CRASH_CATCHER',
        'orders': crash_orders,
        'total_capital': total_capital
    }


def setup_pump_catcher(coin: str, current_price: float = None):
    """
    Pump Catcher - catches violent upward wicks (short squeezes).
    
    In a bear market, shorts get crowded. When unexpected good news hits,
    the short squeeze can be violent. This catches those wicks.
    
    Places limit SELL orders above current price to short the spike.
    """
    regime = detect_market_regime(coin)
    price = current_price or regime['price']
    
    print(f"\n{'='*50}")
    print(f"🚀 SHORT SQUEEZE CATCHER SETUP")
    print(f"{'='*50}")
    print(f"   Purpose: Short violent upward wicks (bear market squeezes)")
    print(f"   Current Price: ${price:,.2f}")
    
    # In a bearish trend, also set up orders to catch upward wicks
    pump_levels = [0.08, 0.12, 0.15, 0.20]  # 8%, 12%, 15%, 20% above
    pump_orders = []
    
    print(f"\n   🎯 SQUEEZE SHORT ORDERS:")
    for pct in pump_levels:
        pump_price = price * (1 + pct)
        take_profit = pump_price * (1 - CRASH_TAKE_PROFIT_PCT)
        
        pump_orders.append({
            'type': 'SQUEEZE_SHORT',
            'trigger_pump': f"{pct*100:.0f}%",
            'short_price': pump_price,
            'take_profit': take_profit,
            'size_usd': CRASH_SIZE_USD * 0.5  # Smaller size for shorts (riskier)
        })
        
        print(f"      {pct*100:.0f}% pump → Short at ${pump_price:,.2f}")
        print(f"                  → TP at ${take_profit:,.2f} (-5%)")
        print()
        
        if exchange:
            sz = (CRASH_SIZE_USD * 0.5) / pump_price
            # Place limit sell (short) order
            # exchange.order(coin, is_buy=False, sz=sz, px=pump_price,
            #                order_type={"limit": {"tif": "Gtc"}})
    
    if not exchange:
        print(f"\n⚠️ Test mode - no orders placed")
    
    return {
        'action': 'SETUP_PUMP_CATCHER',
        'orders': pump_orders
    }


def update_crash_catchers(coin: str):
    """
    Update crash catcher orders when price moves significantly.
    
    If price drops 5%+, cancel old orders and place new ones at new levels.
    This keeps your wick catchers relevant.
    """
    regime = detect_market_regime(coin)
    current_price = regime['price']
    
    print(f"\n🔄 Updating crash catchers to current price ${current_price:,.2f}")
    
    # Cancel existing crash catcher orders
    if exchange and info:
        open_orders = info.open_orders(ACCOUNT_ADDR)
        for order in open_orders:
            if order['coin'] == coin:
                # Check if it's a crash catcher order (far from current price)
                order_price = float(order['limitPx'])
                distance = abs(order_price - current_price) / current_price
                if distance > 0.08:  # More than 8% away = crash catcher
                    exchange.cancel(coin, order['oid'])
    
    # Set up new crash catchers at current levels
    setup_crash_catcher(coin, current_price)
    setup_pump_catcher(coin, current_price)


# =============================================================================
# MAIN STRATEGY LOGIC
# =============================================================================

def run_strategy(coin: str, position_size_usd: float = 1000):
    """
    Main strategy loop.
    
    1. Detect market regime (trending or choppy)
    2. If trending → enter leveraged position, ride the move
    3. If choppy → run neutral grid, profit from volatility
    4. ALWAYS → Set up crash catchers for black swan events
    """
    
    print(f"""
╔══════════════════════════════════════════════════════════════════╗
║          DOWNSIDE SPECIALIST - 2026 FIRE HORSE YEAR              ║
╠══════════════════════════════════════════════════════════════════╣
║  Three modes:                                                    ║
║  • TRENDING → Leveraged position (10x short / 3x long)           ║
║  • CHOPPY   → Neutral grid (profit from volatility)              ║
║  • ALWAYS   → Flash crash catchers (catch Oct 10-style wicks)    ║
╚══════════════════════════════════════════════════════════════════╝
    """)
    
    # Step 1: Detect regime
    regime = detect_market_regime(coin)
    
    print(f"\n📊 MARKET REGIME ANALYSIS")
    print(f"{'='*50}")
    print(f"   13 MA: ${regime['ma13']:,.2f}")
    print(f"   33 MA: ${regime['ma33']:,.2f}")
    print(f"   Difference: {regime['ma_diff_pct']:+.2f}%")
    print(f"   Fresh Cross: {'Yes ⚡' if regime['fresh_cross'] else 'No'}")
    print(f"   Current Price: ${regime['price']:,.2f}")
    print(f"\n   📍 REGIME: {regime['regime']}")
    
    # Step 2: Execute appropriate strategy
    if regime['regime'] == "TRENDING_SHORT":
        print(f"\n🐻 BEARISH TREND DETECTED")
        print(f"   → 13 MA below 33 MA")
        print(f"   → Entering SHORT position with {LEVERAGE_SHORT}x leverage")
        print(f"   → Will ride the move down with stop loss")
        
        # Cancel any existing grid
        cancel_grid(coin)
        
        # Enter short position
        result = enter_trend_position(coin, "SHORT", position_size_usd)
        
    elif regime['regime'] == "TRENDING_LONG":
        print(f"\n🐂 BULLISH TREND DETECTED")
        print(f"   → 13 MA above 33 MA")
        print(f"   → Entering LONG position with {LEVERAGE_LONG}x leverage")
        print(f"   → Conservative size (bearish 2026 thesis)")
        
        # Cancel any existing grid
        cancel_grid(coin)
        
        # Enter long position (smaller size due to bearish thesis)
        result = enter_trend_position(coin, "LONG", position_size_usd * 0.5)
        
    else:  # CHOPPY
        print(f"\n🔀 CHOPPY MARKET DETECTED")
        print(f"   → MAs are close together (no clear trend)")
        print(f"   → Setting up neutral grid to profit from chop")
        print(f"   → Will switch to trend mode when 13/33 cross confirms")
        
        # Close any trend positions
        exit_trend_position(coin)
        
        # Set up neutral grid
        result = setup_neutral_grid(coin)
    
    # ALWAYS set up crash catchers (runs alongside main strategy)
    print(f"\n{'='*50}")
    print(f"🌪️ SETTING UP BLACK SWAN CATCHERS")
    print(f"{'='*50}")
    print(f"   These run 24/7 alongside your main strategy.")
    print(f"   Waiting for liquidation cascades like Oct 10, 2025.")
    
    crash_result = setup_crash_catcher(coin)
    pump_result = setup_pump_catcher(coin)
    
    # Combine results
    result['crash_catcher'] = crash_result
    result['pump_catcher'] = pump_result
    
    return result


def check_and_update(coin: str):
    """
    Periodic check - run this on a schedule (e.g., daily).
    
    Checks if regime has changed and updates positions accordingly.
    """
    print(f"\n🔄 PERIODIC CHECK - {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    
    regime = detect_market_regime(coin)
    
    print(f"   Current regime: {regime['regime']}")
    print(f"   Fresh cross: {regime['fresh_cross']}")
    
    if regime['fresh_cross']:
        print(f"\n⚡ FRESH CROSS DETECTED - Updating strategy...")
        return run_strategy(coin)
    else:
        print(f"   No change - maintaining current positions")
        return None


# =============================================================================
# ENTRY POINT
# =============================================================================

if __name__ == "__main__":
    # Run the strategy
    result = run_strategy(SYMBOL)
    
    print(f"\n{'='*50}")
    print(f"Strategy executed. Result: {result['action'] if result else 'None'}")
    print(f"{'='*50}")
